/*
Navicat MySQL Data Transfer

Source Server         : 192.168.172.171
Source Server Version : 50613
Source Host           : 192.168.172.171:3306
Source Database       : LoginServer1

Target Server Type    : MYSQL
Target Server Version : 50613
File Encoding         : 65001

Date: 2017-08-11 15:02:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for active_account
-- ----------------------------
DROP TABLE IF EXISTS `active_account`;
CREATE TABLE `active_account` (
  `active_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `account` char(64) NOT NULL DEFAULT '',
  `game_type` int(11) unsigned NOT NULL DEFAULT '0',
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`active_id`),
  UNIQUE KEY `index` (`account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of active_account
-- ----------------------------

-- ----------------------------
-- Table structure for lock_account
-- ----------------------------
DROP TABLE IF EXISTS `lock_account`;
CREATE TABLE `lock_account` (
  `lock_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `account` char(64) NOT NULL DEFAULT '',
  `game_type` int(11) unsigned NOT NULL DEFAULT '0',
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `operate_flag` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`lock_id`),
  UNIQUE KEY `index` (`account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of lock_account
-- ----------------------------

-- ----------------------------
-- Table structure for lock_bindaddmark
-- ----------------------------
DROP TABLE IF EXISTS `lock_bindaddmark`;
CREATE TABLE `lock_bindaddmark` (
  `lock_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bindaddmark` char(13) NOT NULL DEFAULT '',
  `macAddr` char(13) NOT NULL DEFAULT '',
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`lock_id`),
  UNIQUE KEY `index` (`bindaddmark`,`macAddr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of lock_bindaddmark
-- ----------------------------

-- ----------------------------
-- Table structure for wzoneInfo
-- ----------------------------
DROP TABLE IF EXISTS `wzoneInfo`;
CREATE TABLE `wzoneInfo` (
  `game` int(10) unsigned NOT NULL DEFAULT '0',
  `zone` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(100) NOT NULL DEFAULT '',
  `port` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `desc` varchar(100) NOT NULL DEFAULT '',
  `IsUse` int(10) unsigned NOT NULL DEFAULT '0',
  `desc_order` varchar(100) NOT NULL DEFAULT '',
  `destGame` int(10) unsigned NOT NULL DEFAULT '0',
  `destZone` int(10) unsigned NOT NULL DEFAULT '0',
  `operation` varchar(255) NOT NULL DEFAULT '',
  `state` bigint(20) NOT NULL DEFAULT '0',
  `loginUrl` varchar(255) NOT NULL DEFAULT '',
  `billingUrl` varchar(255) NOT NULL DEFAULT '',
  `maintenanceInfo` varchar(255) NOT NULL DEFAULT '',
  `copartnerID` int(10) unsigned NOT NULL DEFAULT '0',
  `openZoneTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `createTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastUpdTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`game`,`zone`),
  UNIQUE KEY `ip_port` (`ip`,`port`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of wzoneInfo
-- ----------------------------

-- ----------------------------
-- Table structure for zoneInfo
-- ----------------------------
DROP TABLE IF EXISTS `zoneInfo`;
CREATE TABLE `zoneInfo` (
  `game` int(10) unsigned NOT NULL DEFAULT '0',
  `zone` int(10) unsigned NOT NULL DEFAULT '0',
  `zoneType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `port` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cap` varchar(16) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `x` int(10) unsigned NOT NULL DEFAULT '0',
  `y` int(10) unsigned NOT NULL DEFAULT '0',
  `desc` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `IsUse` int(10) unsigned NOT NULL DEFAULT '0',
  `desc_order` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `destGame` int(10) unsigned NOT NULL DEFAULT '0',
  `destZone` int(10) unsigned NOT NULL DEFAULT '0',
  `operation` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flag_test` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`game`,`zone`),
  UNIQUE KEY `ip_port` (`ip`,`port`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of zoneInfo
-- ----------------------------
INSERT INTO `zoneInfo` VALUES ('10019', '1', '1', '192.168.181.68', '30101', 'pqq', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '2', '1', '192.168.181.72', '30101', 'dhc', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '3', '1', '192.168.181.210', '30101', 'qa1', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '4', '1', '192.168.181.119', '30101', 'qa2', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '5', '1', '192.168.181.212', '35101', 'wzy', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '6', '1', '192.168.181.134', '30101', 'xsz', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '7', '1', '192.168.181.211', '30101', 'mzy', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '8', '1', '192.168.181.136', '30101', 'hw', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '9', '1', '192.168.181.144', '30101', 'qa3', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '10', '1', '192.168.181.144', '20101', 'zzf', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '11', '1', '192.168.181.133', '35101', 'wzy2', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '12', '1', '192.168.181.172', '30101', 'qa4', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '13', '1', '192.168.181.171', '30101', 'mzy', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
INSERT INTO `zoneInfo` VALUES ('10019', '14', '1', '192.168.181.135', '30101', 'wuhan', '0', '', '0', '0', '', '1', '', '0', '0', '', '');
