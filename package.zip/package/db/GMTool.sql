/*
Navicat MySQL Data Transfer

Source Server         : 192.168.172.171
Source Server Version : 50613
Source Host           : 192.168.172.171:3306
Source Database       : GMTool

Target Server Type    : MYSQL
Target Server Version : 50613
File Encoding         : 65001

Date: 2017-08-11 15:02:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for BroadCast
-- ----------------------------
DROP TABLE IF EXISTS `BroadCast`;
CREATE TABLE `BroadCast` (
  `ncount` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ZONE` int(10) unsigned NOT NULL DEFAULT '0',
  `country` int(10) unsigned NOT NULL DEFAULT '0',
  `area` int(11) unsigned NOT NULL DEFAULT '0',
  `content` varchar(255) NOT NULL DEFAULT '',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `interval` int(10) unsigned NOT NULL DEFAULT '0',
  `SEND_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `STOP_TIME` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `id` bigint(11) unsigned NOT NULL DEFAULT '0',
  `IsValid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `gm` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`ncount`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of BroadCast
-- ----------------------------

-- ----------------------------
-- Table structure for BroadCastMaxID
-- ----------------------------
DROP TABLE IF EXISTS `BroadCastMaxID`;
CREATE TABLE `BroadCastMaxID` (
  `ID` bigint(20) NOT NULL DEFAULT '1',
  `rtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of BroadCastMaxID
-- ----------------------------

-- ----------------------------
-- Table structure for BroadCastRule
-- ----------------------------
DROP TABLE IF EXISTS `BroadCastRule`;
CREATE TABLE `BroadCastRule` (
  `ncount` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ZONE` int(10) unsigned NOT NULL DEFAULT '0',
  `country` int(10) unsigned NOT NULL DEFAULT '0',
  `area` int(11) NOT NULL DEFAULT '0',
  `content` varchar(255) NOT NULL DEFAULT '',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `interval` int(10) unsigned NOT NULL DEFAULT '0',
  `send_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `start_time` bigint(20) NOT NULL DEFAULT '0',
  `stop_time` bigint(20) NOT NULL DEFAULT '0',
  `id` bigint(11) NOT NULL DEFAULT '0',
  `mapID` int(10) unsigned NOT NULL DEFAULT '0',
  `gm` varchar(100) NOT NULL DEFAULT '',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `optime` int(10) unsigned NOT NULL DEFAULT '0',
  `IsValid` tinyint(1) NOT NULL DEFAULT '1',
  `rmer` varchar(32) NOT NULL DEFAULT '',
  `rm_time` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ncount`),
  KEY `index_id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of BroadCastRule
-- ----------------------------

-- ----------------------------
-- Table structure for gmstate
-- ----------------------------
DROP TABLE IF EXISTS `gmstate`;
CREATE TABLE `gmstate` (
  `gmname` varchar(64) NOT NULL DEFAULT '',
  `time` bigint(15) NOT NULL DEFAULT '0',
  `state` int(10) unsigned NOT NULL DEFAULT '0',
  `reason` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gmstate
-- ----------------------------

-- ----------------------------
-- Table structure for gmToolPunish20170726
-- ----------------------------
DROP TABLE IF EXISTS `gmToolPunish20170726`;
CREATE TABLE `gmToolPunish20170726` (
  `username` varchar(32) CHARACTER SET utf8 NOT NULL,
  `country` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `server` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `gm` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `reason` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `operation` int(10) DEFAULT NULL,
  `startTime` bigint(20) DEFAULT NULL,
  `delay` bigint(20) DEFAULT NULL,
  `chatTime` bigint(20) DEFAULT NULL,
  `chatContent` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gmToolPunish20170726
-- ----------------------------
INSERT INTO `gmToolPunish20170726` VALUES ('abc', 'ËÎ¹ú', 'test_server', 'realname', 'å…ˆè­¦å‘Šä¸€ä¸‹', '4', '1501060590', '0', '1501061002', 'what is it?');
INSERT INTO `gmToolPunish20170726` VALUES ('abc', 'ËÎ¹ú', 'test_server', 'realname', 'çœ‹ä½ ä¸é¡ºçœ¼', '4', '1501062318', '0', '1501062734', 'what is it?');
INSERT INTO `gmToolPunish20170726` VALUES ('abc', 'ËÎ¹ú', 'test_server', 'realname', '111', '4', '1501062484', '0', '1501062904', 'what is it?');
INSERT INTO `gmToolPunish20170726` VALUES ('abc', 'ËÎ¹ú', 'test_server', 'realname', 'aaa', '4', '1501062799', '0', '1501063222', 'what is it?');

-- ----------------------------
-- Table structure for gmToolPunish20170731
-- ----------------------------
DROP TABLE IF EXISTS `gmToolPunish20170731`;
CREATE TABLE `gmToolPunish20170731` (
  `username` varchar(32) CHARACTER SET utf8 NOT NULL,
  `country` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `server` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `gm` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `reason` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `operation` int(10) DEFAULT NULL,
  `startTime` bigint(20) DEFAULT NULL,
  `delay` bigint(20) DEFAULT NULL,
  `chatTime` bigint(20) DEFAULT NULL,
  `chatContent` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gmToolPunish20170731
-- ----------------------------
INSERT INTO `gmToolPunish20170731` VALUES ('ä¸œå®«å¾·é¸¿', '³þ¹ú', 'pqq', 'realname', 'vv', '1', '1501474489', '180', '1501473402', '11111111111111111111111111111111');
INSERT INTO `gmToolPunish20170731` VALUES ('ä¸œå®«å¾·é¸¿', '³þ¹ú', 'pqq', 'realname', '1111111111', '1', '1501474841', '180', '1501475271', '11111111111111111111');
INSERT INTO `gmToolPunish20170731` VALUES ('ä¸œå®«å¾·é¸¿', '³þ¹ú', 'pqq', 'realname', '1111111111', '1', '1501475149', '180', '1501475562', '·ûºÏ¹æ»®');
INSERT INTO `gmToolPunish20170731` VALUES ('ä¸œå®«å¾·é¸¿', '³þ¹ú', 'pqq', 'realname', '1111111111', '1', '1501475240', '0', '1501475562', '·ûºÏ¹æ»®');

-- ----------------------------
-- Table structure for gmToolPunish20170802
-- ----------------------------
DROP TABLE IF EXISTS `gmToolPunish20170802`;
CREATE TABLE `gmToolPunish20170802` (
  `username` varchar(32) CHARACTER SET utf8 NOT NULL,
  `country` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `server` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `gm` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `reason` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `operation` int(10) DEFAULT NULL,
  `startTime` bigint(20) DEFAULT NULL,
  `delay` bigint(20) DEFAULT NULL,
  `chatTime` bigint(20) DEFAULT NULL,
  `chatContent` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gmToolPunish20170802
-- ----------------------------
INSERT INTO `gmToolPunish20170802` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', '', '', 'realname', ' ', '3', '1501659099', '0', '1501659541', 'Ö÷¶¯´¦·£Íæ¼Ò.');

-- ----------------------------
-- Table structure for gmToolPunish20170804
-- ----------------------------
DROP TABLE IF EXISTS `gmToolPunish20170804`;
CREATE TABLE `gmToolPunish20170804` (
  `username` varchar(32) CHARACTER SET utf8 NOT NULL,
  `country` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `server` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `gm` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `reason` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `operation` int(10) DEFAULT NULL,
  `startTime` bigint(20) DEFAULT NULL,
  `delay` bigint(20) DEFAULT NULL,
  `chatTime` bigint(20) DEFAULT NULL,
  `chatContent` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gmToolPunish20170804
-- ----------------------------
INSERT INTO `gmToolPunish20170804` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', '', '', 'realname', ' ', '3', '1501838995', '0', '1501839440', 'Ö÷¶¯´¦·£Íæ¼Ò.');
INSERT INTO `gmToolPunish20170804` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', '', '', 'realname', ' ', '10', '1501839161', '7200', '1501839606', 'Ö÷¶¯´¦·£Íæ¼Ò.');
INSERT INTO `gmToolPunish20170804` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', '', '', 'realname', ' ', '1', '1501839451', '7200', '1501839896', 'Ö÷¶¯´¦·£Íæ¼Ò.');
INSERT INTO `gmToolPunish20170804` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', 'ÇØ¹ú', 'pqq', 'realname', ' ', '1', '1501839483', '7200', '1501839899', '1');
INSERT INTO `gmToolPunish20170804` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', 'ÇØ¹ú', 'pqq', 'realname', ' ', '1', '1501839586', '0', '1501839899', '1');
INSERT INTO `gmToolPunish20170804` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', '', '', 'realname', '  ', '1', '1501839603', '7200', '1501840048', 'Ö÷¶¯´¦·£Íæ¼Ò.');

-- ----------------------------
-- Table structure for gmToolPunish20170809
-- ----------------------------
DROP TABLE IF EXISTS `gmToolPunish20170809`;
CREATE TABLE `gmToolPunish20170809` (
  `username` varchar(32) CHARACTER SET utf8 NOT NULL,
  `country` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `server` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `gm` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `reason` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `operation` int(10) DEFAULT NULL,
  `startTime` bigint(20) DEFAULT NULL,
  `delay` bigint(20) DEFAULT NULL,
  `chatTime` bigint(20) DEFAULT NULL,
  `chatContent` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gmToolPunish20170809
-- ----------------------------
INSERT INTO `gmToolPunish20170809` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', 'ÇØ¹ú', 'pqq', 'realname', '1', '4', '1502282358', '0', '1502282801', '2');
INSERT INTO `gmToolPunish20170809` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', 'ÇØ¹ú', 'pqq', 'realname', '1', '1', '1502282369', '180', '1502282801', '2');
INSERT INTO `gmToolPunish20170809` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', 'ÇØ¹ú', 'pqq', 'realname', '1', '1', '1502282400', '0', '1502282801', '2');
INSERT INTO `gmToolPunish20170809` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', 'ÇØ¹ú', 'pqq', 'realname', '1', '6', '1502282821', '180', '1502283136', 'cvbcvbcvbcvbcvbcvbcvb');
INSERT INTO `gmToolPunish20170809` VALUES ('ä¸€äºŒä¸‰å››äº”å…­', 'ÇØ¹ú', 'pqq', 'realname', '1', '6', '1502282839', '0', '1502283136', 'cvbcvbcvbcvbcvbcvbcvb');

-- ----------------------------
-- Table structure for GuideRLog
-- ----------------------------
DROP TABLE IF EXISTS `GuideRLog`;
CREATE TABLE `GuideRLog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ZONE` int(10) unsigned NOT NULL DEFAULT '0',
  `country` int(10) unsigned NOT NULL DEFAULT '0',
  `mapID` int(10) unsigned NOT NULL DEFAULT '0',
  `gmName` varchar(100) NOT NULL DEFAULT '',
  `userName` varchar(100) NOT NULL DEFAULT '',
  `content` varchar(255) NOT NULL DEFAULT '',
  `opFlag` int(10) unsigned NOT NULL DEFAULT '0',
  `chatFlag` int(10) unsigned NOT NULL DEFAULT '0',
  `rTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `s_index` (`rTime`,`opFlag`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of GuideRLog
-- ----------------------------

-- ----------------------------
-- Table structure for IMPORT
-- ----------------------------
DROP TABLE IF EXISTS `IMPORT`;
CREATE TABLE `IMPORT` (
  `zone` text NOT NULL,
  `country` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `sendtime` bigint(10) NOT NULL DEFAULT '0',
  `stoptime` bigint(15) DEFAULT NULL,
  `intval` int(10) NOT NULL DEFAULT '0',
  `gm` varchar(128) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of IMPORT
-- ----------------------------

-- ----------------------------
-- Table structure for replytime
-- ----------------------------
DROP TABLE IF EXISTS `replytime`;
CREATE TABLE `replytime` (
  `gmname` varchar(64) NOT NULL DEFAULT '',
  `rolename` varchar(64) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `action` text NOT NULL,
  `chufatime` bigint(15) NOT NULL DEFAULT '0',
  `begintime` bigint(15) NOT NULL DEFAULT '0',
  `endtime` bigint(15) NOT NULL DEFAULT '0',
  `yanshi` bigint(15) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of replytime
-- ----------------------------

-- ----------------------------
-- Table structure for test
-- ----------------------------
DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `id` bigint(11) unsigned NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `gm` varchar(100) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of test
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
