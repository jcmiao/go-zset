/*
Navicat MySQL Data Transfer

Source Server         : 192.168.172.171
Source Server Version : 50613
Source Host           : 192.168.172.171:3306
Source Database       : gm_tool_auth

Target Server Type    : MYSQL
Target Server Version : 50613
File Encoding         : 65001

Date: 2017-08-11 15:01:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for game_type
-- ----------------------------
DROP TABLE IF EXISTS `game_type`;
CREATE TABLE `game_type` (
  `game_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `game_type_code` int(11) NOT NULL DEFAULT '0',
  `game_type_name` char(125) NOT NULL DEFAULT '',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_upd_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`game_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of game_type
-- ----------------------------

-- ----------------------------
-- Table structure for gm_account
-- ----------------------------
DROP TABLE IF EXISTS `gm_account`;
CREATE TABLE `gm_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_name` varchar(50) NOT NULL DEFAULT '',
  `gm_password` varchar(32) NOT NULL DEFAULT '',
  `regtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastupdtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gm_user_name` (`gm_user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_account
-- ----------------------------
INSERT INTO `gm_account` VALUES ('1', 'miaojianchao', 'e10adc3949ba59abbe56e057f20f883e', '0000-00-00 00:00:00', '2017-07-05 10:00:57');
INSERT INTO `gm_account` VALUES ('2', 'miaojianchao2', 'e10adc3949ba59abbe56e057f20f883e', '0000-00-00 00:00:00', '2017-07-26 03:47:50');

-- ----------------------------
-- Table structure for gm_batchreply_tpl
-- ----------------------------
DROP TABLE IF EXISTS `gm_batchreply_tpl`;
CREATE TABLE `gm_batchreply_tpl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_id` int(11) DEFAULT NULL,
  `tpl_info` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gm_user_id` (`gm_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_batchreply_tpl
-- ----------------------------

-- ----------------------------
-- Table structure for gm_bosskey_set
-- ----------------------------
DROP TABLE IF EXISTS `gm_bosskey_set`;
CREATE TABLE `gm_bosskey_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_id` int(11) DEFAULT NULL,
  `bosskey` varchar(128) NOT NULL DEFAULT '',
  `delay` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `reason` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gm_user_id` (`gm_user_id`,`bosskey`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_bosskey_set
-- ----------------------------

-- ----------------------------
-- Table structure for gm_broadcast_tpl
-- ----------------------------
DROP TABLE IF EXISTS `gm_broadcast_tpl`;
CREATE TABLE `gm_broadcast_tpl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_id` int(11) DEFAULT NULL,
  `tpl_info` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gm_user_id` (`gm_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_broadcast_tpl
-- ----------------------------

-- ----------------------------
-- Table structure for gm_chat_channel_type
-- ----------------------------
DROP TABLE IF EXISTS `gm_chat_channel_type`;
CREATE TABLE `gm_chat_channel_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel_type_code` int(11) NOT NULL DEFAULT '0',
  `channel_type_name` varchar(50) DEFAULT NULL,
  `game_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `channel_type_code` (`channel_type_code`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_chat_channel_type
-- ----------------------------
INSERT INTO `gm_chat_channel_type` VALUES ('1', '1', 'shiliao', '10019');
INSERT INTO `gm_chat_channel_type` VALUES ('2', '2', 'qingliao', '10019');
INSERT INTO `gm_chat_channel_type` VALUES ('3', '3', 'duiwu', '10019');
INSERT INTO `gm_chat_channel_type` VALUES ('4', '4', 'haoyou', '10019');
INSERT INTO `gm_chat_channel_type` VALUES ('5', '12', 'guojia', '10019');
INSERT INTO `gm_chat_channel_type` VALUES ('6', '14', 'jiazu', '10019');
INSERT INTO `gm_chat_channel_type` VALUES ('7', '26', 'shijie', '10019');
INSERT INTO `gm_chat_channel_type` VALUES ('8', '47', 'quyu', '10019');
INSERT INTO `gm_chat_channel_type` VALUES ('9', '48', 'zhubo', '10019');

-- ----------------------------
-- Table structure for gm_chat_set
-- ----------------------------
DROP TABLE IF EXISTS `gm_chat_set`;
CREATE TABLE `gm_chat_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_id` int(11) DEFAULT NULL,
  `channel_type_code` int(11) DEFAULT NULL,
  `channel_front_color` int(11) DEFAULT '0',
  `channel_back_color` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `channel_type_code` (`channel_type_code`,`gm_user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=129 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_chat_set
-- ----------------------------
INSERT INTO `gm_chat_set` VALUES ('102', '1', '1', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('120', '2', '1', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('121', '2', '2', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('122', '2', '3', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('123', '2', '4', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('124', '2', '12', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('125', '2', '14', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('126', '2', '26', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('127', '2', '47', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('128', '2', '48', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('103', '1', '2', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('104', '1', '3', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('105', '1', '4', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('106', '1', '12', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('107', '1', '14', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('108', '1', '26', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('109', '1', '47', '16777215', '32896');
INSERT INTO `gm_chat_set` VALUES ('110', '1', '48', '16777215', '32896');

-- ----------------------------
-- Table structure for gm_chat_tpl
-- ----------------------------
DROP TABLE IF EXISTS `gm_chat_tpl`;
CREATE TABLE `gm_chat_tpl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_id` int(11) DEFAULT NULL,
  `tpl_info` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gm_user_id` (`gm_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_chat_tpl
-- ----------------------------

-- ----------------------------
-- Table structure for gm_group
-- ----------------------------
DROP TABLE IF EXISTS `gm_group`;
CREATE TABLE `gm_group` (
  `gm_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_group_name` varchar(125) NOT NULL DEFAULT '',
  `remark` text,
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_upd_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `game_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`gm_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_group
-- ----------------------------

-- ----------------------------
-- Table structure for gm_logininfo
-- ----------------------------
DROP TABLE IF EXISTS `gm_logininfo`;
CREATE TABLE `gm_logininfo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `game_type` int(11) unsigned NOT NULL DEFAULT '0',
  `server_ip` varchar(16) NOT NULL DEFAULT '0.0.0.0',
  `server_port` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=173 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_logininfo
-- ----------------------------
INSERT INTO `gm_logininfo` VALUES ('171', 'miaojianchao2', '10019', '192.168.172.171', '9904');

-- ----------------------------
-- Table structure for gm_punish_tpl
-- ----------------------------
DROP TABLE IF EXISTS `gm_punish_tpl`;
CREATE TABLE `gm_punish_tpl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_id` int(11) DEFAULT NULL,
  `tpl_info` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gm_user_id` (`gm_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_punish_tpl
-- ----------------------------

-- ----------------------------
-- Table structure for gm_sense_set
-- ----------------------------
DROP TABLE IF EXISTS `gm_sense_set`;
CREATE TABLE `gm_sense_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_id` int(11) DEFAULT NULL,
  `sensewords` text,
  `type` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gm_user_id` (`gm_user_id`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_sense_set
-- ----------------------------
INSERT INTO `gm_sense_set` VALUES ('65', '1', 'abc', '0');
INSERT INTO `gm_sense_set` VALUES ('66', '1', '', '1');
INSERT INTO `gm_sense_set` VALUES ('67', '1', '', '3');
INSERT INTO `gm_sense_set` VALUES ('68', '1', '', '2');
INSERT INTO `gm_sense_set` VALUES ('73', '2', '1|2|3|ÎÒ', '0');
INSERT INTO `gm_sense_set` VALUES ('74', '2', '', '1');
INSERT INTO `gm_sense_set` VALUES ('75', '2', '', '3');
INSERT INTO `gm_sense_set` VALUES ('76', '2', '', '2');

-- ----------------------------
-- Table structure for gm_tool_auth
-- ----------------------------
DROP TABLE IF EXISTS `gm_tool_auth`;
CREATE TABLE `gm_tool_auth` (
  `gm_auth_id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_auth_name` varchar(50) NOT NULL DEFAULT '',
  `game_type` int(11) DEFAULT NULL,
  `remark` text,
  PRIMARY KEY (`gm_auth_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_tool_auth
-- ----------------------------
INSERT INTO `gm_tool_auth` VALUES ('1', 'regionmonitor', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('2', 'singlemonitor', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('3', 'automonitor', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('4', 'playerfinder', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('5', 'playeronlinetip', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('6', 'chatwithplayer', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('7', 'guideplayer', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('8', 'player_report', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('9', 'blog_report', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('10', 'templatemanage', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('11', 'chatsetting', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('13', 'highshow', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('14', 'pausescroll', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('16', 'regionsetting', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('17', 'punish', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('18', 'clearall', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('19', 'onlysense', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('20', 'scrollcount', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('21', 'serverstate', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('22', 'closerole', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('23', 'releaserole', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('24', 'usermanage', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('25', 'punishplayer', '10019', null);
INSERT INTO `gm_tool_auth` VALUES ('26', 'querypunish', '10019', null);

-- ----------------------------
-- Table structure for gm_user
-- ----------------------------
DROP TABLE IF EXISTS `gm_user`;
CREATE TABLE `gm_user` (
  `gm_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_name` varchar(50) NOT NULL DEFAULT '',
  `gm_user_realname` varchar(50) DEFAULT NULL,
  `isused` int(11) NOT NULL DEFAULT '0',
  `remark` longtext,
  `game_type` int(11) DEFAULT NULL,
  `gm_group_id` int(11) DEFAULT NULL,
  `automax` int(11) NOT NULL DEFAULT '0',
  `bauto` int(1) NOT NULL DEFAULT '0',
  `state` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gm_user_id`),
  KEY `gm_user_name` (`gm_user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_user
-- ----------------------------
INSERT INTO `gm_user` VALUES ('1', 'miaojianchao', 'realname', '1', null, '10019', null, '0', '0', '0');
INSERT INTO `gm_user` VALUES ('2', 'miaojianchao2', 'realname', '1', null, '10019', null, '0', '0', '0');

-- ----------------------------
-- Table structure for gm_user_auth
-- ----------------------------
DROP TABLE IF EXISTS `gm_user_auth`;
CREATE TABLE `gm_user_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gm_user_id` int(11) DEFAULT NULL,
  `gm_auth_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of gm_user_auth
-- ----------------------------
INSERT INTO `gm_user_auth` VALUES ('1', '1', '1');
INSERT INTO `gm_user_auth` VALUES ('2', '1', '2');
INSERT INTO `gm_user_auth` VALUES ('11', '1', '11');
INSERT INTO `gm_user_auth` VALUES ('13', '1', '13');
INSERT INTO `gm_user_auth` VALUES ('14', '1', '14');
INSERT INTO `gm_user_auth` VALUES ('16', '1', '16');
INSERT INTO `gm_user_auth` VALUES ('17', '1', '17');
INSERT INTO `gm_user_auth` VALUES ('18', '1', '18');
INSERT INTO `gm_user_auth` VALUES ('19', '1', '19');
INSERT INTO `gm_user_auth` VALUES ('20', '1', '20');
INSERT INTO `gm_user_auth` VALUES ('21', '1', '21');
INSERT INTO `gm_user_auth` VALUES ('22', '1', '22');
INSERT INTO `gm_user_auth` VALUES ('23', '1', '23');
INSERT INTO `gm_user_auth` VALUES ('24', '1', '24');
INSERT INTO `gm_user_auth` VALUES ('25', '2', '1');
INSERT INTO `gm_user_auth` VALUES ('26', '2', '2');
INSERT INTO `gm_user_auth` VALUES ('35', '2', '11');
INSERT INTO `gm_user_auth` VALUES ('37', '2', '13');
INSERT INTO `gm_user_auth` VALUES ('38', '2', '14');
INSERT INTO `gm_user_auth` VALUES ('40', '2', '16');
INSERT INTO `gm_user_auth` VALUES ('41', '2', '17');
INSERT INTO `gm_user_auth` VALUES ('42', '2', '18');
INSERT INTO `gm_user_auth` VALUES ('43', '2', '19');
INSERT INTO `gm_user_auth` VALUES ('44', '2', '20');
INSERT INTO `gm_user_auth` VALUES ('46', '2', '22');
INSERT INTO `gm_user_auth` VALUES ('47', '2', '23');
INSERT INTO `gm_user_auth` VALUES ('49', '2', '25');
INSERT INTO `gm_user_auth` VALUES ('50', '2', '26');

-- ----------------------------
-- Table structure for online_pri_gm_user
-- ----------------------------
DROP TABLE IF EXISTS `online_pri_gm_user`;
CREATE TABLE `online_pri_gm_user` (
  `online_pri_gm_user_id` int(10) NOT NULL AUTO_INCREMENT,
  `gm_user_id` int(11) NOT NULL DEFAULT '0',
  `game_type` int(11) unsigned NOT NULL DEFAULT '0',
  `pri_str` char(64) NOT NULL DEFAULT '',
  `pri_value` char(64) DEFAULT NULL,
  PRIMARY KEY (`online_pri_gm_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of online_pri_gm_user
-- ----------------------------

-- ----------------------------
-- Table structure for tool_auth
-- ----------------------------
DROP TABLE IF EXISTS `tool_auth`;
CREATE TABLE `tool_auth` (
  `tool_auth_id` int(11) NOT NULL AUTO_INCREMENT,
  `tool_auth_name` varchar(50) NOT NULL DEFAULT '',
  `game_type` int(11) DEFAULT NULL,
  `remark` text,
  PRIMARY KEY (`tool_auth_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tool_auth
-- ----------------------------

-- ----------------------------
-- Table structure for tool_user
-- ----------------------------
DROP TABLE IF EXISTS `tool_user`;
CREATE TABLE `tool_user` (
  `tool_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `game_type` int(11) DEFAULT NULL,
  `tool_user_name` varchar(50) NOT NULL DEFAULT '',
  `tool_user_realname` varchar(50) DEFAULT NULL,
  `remark` longtext,
  PRIMARY KEY (`tool_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tool_user
-- ----------------------------

-- ----------------------------
-- Table structure for tool_user_auth
-- ----------------------------
DROP TABLE IF EXISTS `tool_user_auth`;
CREATE TABLE `tool_user_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tool_user_id` int(11) DEFAULT NULL,
  `tool_auth_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tool_user_id` (`tool_user_id`),
  KEY `tool_auth_id` (`tool_auth_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tool_user_auth
-- ----------------------------
